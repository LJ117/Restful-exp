package dto

type NewAccountResponse struct {
	AccountId string `json:"account_id"`
}
