package main

import (
	"github.com/ashishjuyal/banking/app"
)

func main() {

	app.Start()

}
